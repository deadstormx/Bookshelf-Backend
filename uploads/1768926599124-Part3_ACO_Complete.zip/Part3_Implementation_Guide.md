# Part 3: ACO Multi-Agent Pathfinding - Implementation Guide

## Overview
This implementation provides Ant Colony Optimization (ACO) pathfinding for 3 autonomous agents that pick up or deliver parcels at multiple goal locations, then switch to A* to return to their starting positions.

## Files Created

### Core ACO System
1. **ACOAlgorithm.cs** - Core ACO pathfinding logic with configurable parameters
2. **PheromoneConnection.cs** - Connection class with pheromone trails
3. **ACOGraph.cs** - Graph management with pheromone operations
4. **ACOManager.cs** - High-level ACO manager
5. **ACOTester.cs** - Main agent controller using ACO
6. **UniversalAgentCollisionHandler.cs** - Collision avoidance for both ACO and A* agents

## Setup Instructions

### Step 1: Import Scripts
1. Copy all 6 new C# scripts into your Unity project's `Assets/Scripts` folder
2. Wait for Unity to compile the scripts
3. Ensure no compilation errors appear

### Step 2: Waypoint Setup
Your waypoints should already be set up from Part 2, but ensure:
- All waypoints have the "Waypoint" tag
- All waypoints have the `VisGraphWaypointManager` component
- All waypoints are interconnected (every waypoint can reach every other waypoint)
- **IMPORTANT**: Every waypoint should be marked as a "Goal" type in the inspector

### Step 3: Create Agent 1 (4 Parcels)

#### A. Create Agent GameObject
1. Create an empty GameObject named "Agent1"
2. Position it at your desired starting location
3. Add a 3D model (e.g., Capsule, Car model, etc.)

#### B. Add Required Components
Add these components to Agent1:
1. **ACOTester** (the new script)
2. **UniversalAgentCollisionHandler**
3. **PathfindingTester** (your existing A* script - will be disabled initially)
4. **Rigidbody** (set to Kinematic, no Gravity)
5. **BoxCollider** (set as Trigger)

#### C. Configure ACOTester Component

**Agent Info:**
- Agent Name: "Agent 1"

**ACO Parameters:**
- Alpha: 1.0 (pheromone importance)
- Beta: 2.0 (heuristic importance)
- Q: 100 (pheromone deposit constant)
- Default Pheromone: 1.0
- Evaporation Factor: 0.5

**Waypoints:**
- Start Node: Drag your starting waypoint here

**Movement:**
- Base Speed: 6.0
- Rotation Speed: 5.0
- Arrive Distance: 1.5

**Scenario Type:**
- Select either "Pickup" or "Drop" (keep consistent for all agents)

**Parcels:**
- Set size to 4
- For each parcel:
  - Parcel Object: Create small GameObject (e.g., Cube scaled to 0.5)
  - Goal Location: Drag a different waypoint for each parcel
  - Place parcel objects near starting position

**Parcel Container:**
- Create an empty child GameObject of Agent1 named "ParcelContainer"
- Position it appropriately on your agent (e.g., on top of a bus/car)
- Drag this into the "Parcel Container" field

**Goal Settings:**
- Wait At Goal Time: 3.0

#### D. Setup UI Canvas for Agent1
Create a Canvas (World Space) as a child of Agent1:

1. **Canvas Settings:**
   - Render Mode: World Space
   - Position above agent (Y offset ~2-3 units)
   - Scale: 0.01, 0.01, 0.01
   - Width: 400, Height: 600

2. **Add TextMeshPro UI Elements:**
   Create these as children of the Canvas:
   
   - **Agent Name Text**
     - Text: "Agent 1"
     - Font Size: 24, Bold
     - Alignment: Center
     
   - **Speed Text**
     - Text: "Speed: 0.0"
     - Font Size: 18
     
   - **Distance Text**
     - Text: "Distance: 0.0"
     - Font Size: 18
     
   - **Package Text**
     - Text: "Parcels: 4"
     - Font Size: 18
     
   - **Status Text**
     - Text: "Status: Idle"
     - Font Size: 18
     
   - **Collision Info Text**
     - Text: "No Collision"
     - Font Size: 16
     - Color: Yellow
     
   - **Alpha Text**
     - Text: "α: 1.00"
     - Font Size: 16
     
   - **Beta Text**
     - Text: "β: 2.00"
     - Font Size: 16
     
   - **Q Text**
     - Text: "Q: 100.0"
     - Font Size: 16

3. **Assign UI References:**
   - Drag each TextMeshPro element to its corresponding field in ACOTester
   - Also assign Collision Status Text to UniversalAgentCollisionHandler

### Step 4: Create Agent 2 (3 Parcels)

1. Duplicate Agent1
2. Rename to "Agent2"
3. **Position at a DIFFERENT starting location**
4. Update ACOTester:
   - Agent Name: "Agent 2"
   - Start Node: Different starting waypoint
   - Parcels: Set size to 3
     - Assign 3 different goal locations (different from Agent1)
   - Update Canvas text to show "Agent 2"

### Step 5: Create Agent 3 (3 Parcels)

1. Duplicate Agent1 or Agent2
2. Rename to "Agent3"
3. **Position at a THIRD different starting location**
4. Update ACOTester:
   - Agent Name: "Agent 3"
   - Start Node: Third starting waypoint (different from Agent1 & Agent2)
   - Parcels: Set size to 3
     - Assign 3 different goal locations
   - Update Canvas text to show "Agent 3"

### Step 6: Configure PathfindingTester for Return Journey

For each agent, configure the PathfindingTester component:
1. **Leave it DISABLED** (uncheck the component)
2. Set the same parameters:
   - Agent Name: (same as ACOTester)
   - Start Node: (same as ACOTester)
   - Goal Node: (same as ACOTester Start Node - for return trip)
   - Move Speed: 6.0
   - Rotation Speed: 5.0
   - Arrive Distance: 1.0

## How It Works

### Phase 1: ACO Navigation (Pickup/Delivery)
1. Agent starts at its starting waypoint
2. Uses ACO to navigate to first parcel goal location
3. Waits 3 seconds at goal
4. Picks up or drops parcel (depending on scenario type)
5. Speed changes according to formula:
   - **Pickup**: `speed = baseSpeed * 0.9^remainingParcels`
   - **Drop**: `speed = baseSpeed * 1.1^deliveredCount`
6. Repeats for all assigned parcels
7. ACO updates pheromone trails after each successful path

### Phase 2: Switch to A*
1. After all parcels are completed:
   - Agent speed is set to 0
   - ACOTester component is disabled
   - PathfindingTester (A*) component is enabled
2. Agent automatically uses A* to return to starting position
3. Agent stops completely at start position

### Collision Avoidance
- Slower agent yields to faster agent
- Yielding agent:
  1. Steps aside perpendicular to path
  2. Waits for other agent to pass
  3. Returns to original position
  4. Recalculates next waypoint
- UI shows collision status in real-time

## ACO Parameters Explained

- **Alpha (α)**: Controls importance of pheromone trails
  - Higher = agents follow previous successful paths more
  - Range: 0.1 - 5.0
  - Default: 1.0

- **Beta (β)**: Controls importance of distance heuristic
  - Higher = agents prefer shorter distances
  - Range: 0.1 - 5.0
  - Default: 2.0

- **Q**: Pheromone deposit amount
  - Higher = stronger pheromone reinforcement
  - Range: 10 - 500
  - Default: 100

- **Default Pheromone**: Initial pheromone on all edges
  - Baseline attractiveness of paths
  - Range: 0.1 - 10.0
  - Default: 1.0

- **Evaporation Factor (ρ)**: Pheromone decay rate
  - Higher = faster forgetting of old paths
  - Range: 0.1 - 0.9
  - Default: 0.5

## Testing Checklist

### Waypoint Verification
- [ ] All waypoints tagged "Waypoint"
- [ ] All waypoints interconnected
- [ ] All waypoints marked as "Goal" type
- [ ] At least 10 different goal locations available

### Agent 1 Verification
- [ ] Has 4 parcels with different goal locations
- [ ] Starts at unique position
- [ ] ACOTester enabled, PathfindingTester disabled
- [ ] All UI elements assigned
- [ ] Collision handler configured

### Agent 2 Verification
- [ ] Has 3 parcels with different goal locations
- [ ] Starts at different position than Agent 1
- [ ] Different goal locations than Agent 1
- [ ] All components properly configured

### Agent 3 Verification
- [ ] Has 3 parcels with different goal locations
- [ ] Starts at different position than Agents 1 & 2
- [ ] Different goal locations than other agents
- [ ] All components properly configured

### Runtime Verification
- [ ] Each agent navigates using ACO
- [ ] Speed changes correctly after each parcel
- [ ] Agents wait 3 seconds at each goal
- [ ] Collision avoidance works (slower yields to faster)
- [ ] After all parcels, agents switch to A*
- [ ] Agents return to starting positions
- [ ] Agents stop completely at start (speed = 0)
- [ ] UI displays correct information
- [ ] ACO parameters visible in UI

## Troubleshooting

### Agent doesn't move
- Check that ACOTester is enabled
- Verify Start Node is assigned
- Verify at least one parcel has a valid Goal Location
- Check that waypoints are interconnected

### Agent gets stuck
- Increase Arrive Distance (try 2.0)
- Verify waypoint connections are bidirectional
- Check for duplicate waypoints in connections

### Collision avoidance not working
- Verify Rigidbody is Kinematic with no gravity
- Verify BoxCollider is set as Trigger
- Check collision layer settings
- Ensure both agents have UniversalAgentCollisionHandler

### Speed not changing
- Verify Scenario Type is set correctly
- Check that parcels are being marked as completed
- Debug log the UpdateSpeedBasedOnParcels() function

### Agent doesn't switch to A*
- Verify PathfindingTester component exists
- Check that all parcels have been completed
- Ensure Start Node matches on both components

### UI not updating
- Verify all TextMeshPro components are assigned
- Check that Canvas is visible and properly scaled
- Ensure TextMeshPro package is installed

## Performance Optimization

For better performance:
1. Reduce number of waypoints if possible
2. Use spatial partitioning for collision detection
3. Limit pheromone update frequency
4. Use object pooling for parcel objects

## Advanced Configuration

### Custom Speed Formulas
Edit `UpdateSpeedBasedOnParcels()` in ACOTester.cs:
```csharp
// Example: Linear decrease instead of exponential
currentSpeed = baseSpeed - (remainingParcels * 0.5f);
```

### Custom Pheromone Update
Edit `UpdatePheromones()` in ACOAlgorithm.cs:
```csharp
// Example: Bonus for shorter paths
float bonus = 1.0f / (pathCost + 1.0f);
float pheromoneDeposit = Q * bonus / pathCost;
```

### Custom Path Selection
Edit `FindNextWaypoint()` in ACOAlgorithm.cs:
```csharp
// Example: Add randomness factor
float randomFactor = 0.1f;
probability *= (1.0f + Random.Range(-randomFactor, randomFactor));
```

## Example Scenarios

### Scenario 1: Food Delivery Service
- Scenario Type: Drop
- 3 delivery vehicles
- Each picks up food from restaurant (start)
- Delivers to multiple customer locations (goals)
- Gets faster as they deliver (lighter load)
- Returns to restaurant for next batch

### Scenario 2: Waste Collection
- Scenario Type: Pickup
- 3 garbage trucks
- Start at depot
- Visit multiple collection points (goals)
- Get slower as they fill up (heavier load)
- Return to depot to empty

### Scenario 3: Package Distribution
- Scenario Type: Drop
- 3 courier drones
- Start at warehouse
- Deliver to multiple addresses (goals)
- Speed increases with each delivery
- Return to warehouse for restock

## Expected Behavior Summary

1. **Agent 1**: 4 parcels → visits 4 different goals → returns to start
2. **Agent 2**: 3 parcels → visits 3 different goals → returns to start
3. **Agent 3**: 3 parcels → visits 3 different goals → returns to start
4. **Total**: 10 parcels delivered/picked up
5. **Collision**: Slower agents yield to faster ones
6. **Speed**: Changes by 10% per parcel (max 90% change)
7. **Navigation**: ACO for goals, A* for return
8. **UI**: Shows all required information for each agent

## Contact & Support

If you encounter issues:
1. Check Unity console for error messages
2. Verify all setup steps completed
3. Test with a simple 3-waypoint graph first
4. Enable Gizmos in Scene view to visualize paths
5. Add Debug.Log statements to track agent behavior
