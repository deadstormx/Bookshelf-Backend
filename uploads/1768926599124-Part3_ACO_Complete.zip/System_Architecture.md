# Part 3: System Architecture Overview

## Component Hierarchy

```
Agent GameObject
├── ACOTester.cs (ENABLED initially)
│   ├── ACO Parameters (α, β, Q, ρ, default pheromone)
│   ├── Movement Settings
│   ├── Parcel List (4 or 3 parcels)
│   └── UI References
├── PathfindingTester.cs (DISABLED initially)
│   └── A* Pathfinding for return trip
├── UniversalAgentCollisionHandler.cs
│   └── Collision avoidance logic
├── Rigidbody (Kinematic)
├── BoxCollider (Trigger)
├── Canvas (World Space)
│   ├── Agent Name Text
│   ├── Speed Text
│   ├── Distance Text
│   ├── Package Text
│   ├── Status Text
│   ├── Collision Info Text
│   ├── Alpha Text
│   ├── Beta Text
│   └── Q Text
└── ParcelContainer (Empty GameObject)
    └── Parcel Objects (when picked up)
```

## Data Flow

```
START
  │
  ├─> ACOTester.Start()
  │     ├─> Initialize ACO Manager
  │     ├─> Build graph from waypoints
  │     ├─> Calculate initial speed
  │     └─> Start ACORoutine()
  │
  ├─> ACORoutine() - Main Loop
  │     │
  │     ├─> FOR EACH PARCEL:
  │     │     ├─> NavigateToGoal(goal) using ACO
  │     │     │     ├─> Find next waypoint using pheromones
  │     │     │     ├─> Move to waypoint
  │     │     │     ├─> Update visited list
  │     │     │     └─> Repeat until goal reached
  │     │     │
  │     │     ├─> Wait at goal (3 seconds)
  │     │     │
  │     │     ├─> Handle parcel (pickup/drop)
  │     │     │
  │     │     ├─> Update speed based on parcels
  │     │     │     ├─> Pickup: speed *= 0.9^remaining
  │     │     │     └─> Drop: speed *= 1.1^delivered
  │     │     │
  │     │     └─> Update pheromones on path taken
  │     │
  │     └─> AFTER ALL PARCELS:
  │           ├─> Set speed to 0
  │           ├─> Disable ACOTester
  │           ├─> Enable PathfindingTester (A*)
  │           └─> A* navigates back to start
  │
  └─> END (Agent stopped at start)
```

## ACO Algorithm Flow

```
FindNextWaypoint(current, goal, visited)
  │
  ├─> Get connections from current waypoint
  │
  ├─> Filter out visited waypoints
  │
  ├─> FOR EACH candidate connection:
  │     ├─> Get pheromone level (τ)
  │     ├─> Calculate heuristic (η = 1/distance)
  │     ├─> Calculate probability: P = τ^α * η^β
  │     └─> Add to probability list
  │
  ├─> Normalize probabilities (sum = 1.0)
  │
  ├─> Roulette wheel selection
  │     ├─> Generate random [0,1]
  │     ├─> Select based on cumulative probability
  │     └─> Return selected waypoint
  │
  └─> RETURN next waypoint
```

## Pheromone Update Flow

```
UpdatePheromones(path, pathCost)
  │
  ├─> EVAPORATION PHASE:
  │     └─> For all edges: τ = τ * (1 - ρ)
  │
  └─> DEPOSITION PHASE:
        ├─> Calculate deposit: Δτ = Q / pathCost
        └─> For each edge in path: τ += Δτ
```

## Collision Avoidance Flow

```
OnTriggerEnter(other agent)
  │
  ├─> Check if head-on collision
  │     └─> Dot product of forward vectors > 0.5
  │
  ├─> Compare speeds
  │     ├─> If this.speed < other.speed: YIELD
  │     └─> If speeds equal: alphabetical name comparison
  │
  └─> IF YIELDING:
        ├─> Set IsSteppingAside = true
        ├─> Calculate side position (perpendicular)
        ├─> Move to side position
        ├─> Wait for other agent to pass
        ├─> Return to original position
        ├─> Recalculate next waypoint
        └─> Set IsSteppingAside = false
```

## Agent State Machine

```
┌─────────────┐
│   IDLE      │ Initial state
└──────┬──────┘
       │
       ├─> Start()
       │
┌──────▼──────┐
│  BOARDING   │ Agents pickup scenario only
└──────┬──────┘
       │
┌──────▼──────┐
│  EN ROUTE   │ Navigating using ACO
│  (ACO)      │ ◄─┐
└──────┬──────┘   │
       │          │
       ├─> Collision? ──> STEPPING ASIDE ──┘
       │
┌──────▼──────┐
│  AT GOAL    │ Waiting 3 seconds
└──────┬──────┘
       │
┌──────▼──────┐
│  HANDLING   │ Pickup or drop parcel
│  PARCEL     │
└──────┬──────┘
       │
       ├─> More parcels? ──YES──> EN ROUTE (ACO)
       │
       NO
       │
┌──────▼──────┐
│  SWITCHING  │ Disable ACO, Enable A*
└──────┬──────┘
       │
┌──────▼──────┐
│  RETURNING  │ Using A* pathfinding
│  (A*)       │
└──────┬──────┘
       │
┌──────▼──────┐
│  COMPLETED  │ Stopped at start
└─────────────┘
```

## Speed Calculation Examples

### Pickup Scenario (Getting Heavier)
```
Base Speed: 6.0 m/s
Formula: speed = 6.0 * 0.9^remaining

Agent 1 (4 parcels):
  Start:  6.0 * 0.9^4 = 3.93 m/s
  After 1: 6.0 * 0.9^3 = 4.37 m/s
  After 2: 6.0 * 0.9^2 = 4.86 m/s
  After 3: 6.0 * 0.9^1 = 5.40 m/s
  After 4: 6.0 * 0.9^0 = 6.00 m/s

Agent 2 (3 parcels):
  Start:  6.0 * 0.9^3 = 4.37 m/s
  After 1: 6.0 * 0.9^2 = 4.86 m/s
  After 2: 6.0 * 0.9^1 = 5.40 m/s
  After 3: 6.0 * 0.9^0 = 6.00 m/s
```

### Drop Scenario (Getting Lighter)
```
Base Speed: 6.0 m/s
Formula: speed = 6.0 * 1.1^delivered

Agent 1 (4 parcels):
  Start:  6.0 * 1.1^0 = 6.00 m/s
  After 1: 6.0 * 1.1^1 = 6.60 m/s
  After 2: 6.0 * 1.1^2 = 7.26 m/s
  After 3: 6.0 * 1.1^3 = 7.99 m/s
  After 4: 6.0 * 1.1^4 = 8.78 m/s

Agent 2 (3 parcels):
  Start:  6.0 * 1.1^0 = 6.00 m/s
  After 1: 6.0 * 1.1^1 = 6.60 m/s
  After 2: 6.0 * 1.1^2 = 7.26 m/s
  After 3: 6.0 * 1.1^3 = 7.99 m/s
```

## Agent Configuration Matrix

| Agent   | Parcels | Start Position | Goal Locations | Initial Speed (Drop) | Final Speed (Drop) |
|---------|---------|----------------|----------------|----------------------|--------------------|
| Agent 1 | 4       | Waypoint A     | W1, W2, W3, W4 | 6.00 m/s             | 8.78 m/s          |
| Agent 2 | 3       | Waypoint B     | W5, W6, W7     | 6.00 m/s             | 7.99 m/s          |
| Agent 3 | 3       | Waypoint C     | W8, W9, W10    | 6.00 m/s             | 7.99 m/s          |

**TOTAL: 10 parcels across 10 different goal locations**

## UI Display Elements

```
┌────────────────────────────┐
│       Agent 1              │  <- Agent Name
├────────────────────────────┤
│ Speed: 6.5                 │  <- Current Speed
│ Distance: 142.3            │  <- Total Distance
│ Parcels: 2                 │  <- Remaining Parcels
│ Status: En Route           │  <- Current Status
│ No Collision               │  <- Collision Info
│ α: 1.00                    │  <- Alpha
│ β: 2.00                    │  <- Beta
│ Q: 100.0                   │  <- Q Value
└────────────────────────────┘
```

## Testing Scenarios

### Test 1: Basic Navigation
- All agents reach their goals
- Parcels are handled correctly
- Speed changes as expected
- Agents return to start using A*

### Test 2: Collision Handling
- Slower agent yields to faster
- Yielding agent steps aside
- Yielding agent returns to path
- Both agents continue successfully

### Test 3: Pheromone Convergence
- Run multiple times
- Check if agents find similar paths
- Verify pheromone trails strengthen successful routes

### Test 4: Edge Cases
- Agent starts at goal location
- Agent has only 1 parcel
- All goals are same waypoint (not recommended)
- Speed reaches maximum (90% increase)

## Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| Agent doesn't move | ACOTester disabled | Ensure enabled in inspector |
| Agent goes wrong way | Waypoints not interconnected | Check all connections |
| No collision avoidance | Missing trigger collider | Add BoxCollider as trigger |
| Speed doesn't change | Parcels not completing | Check parcel.completed flag |
| Doesn't switch to A* | PathfindingTester missing | Add component to agent |
| UI not updating | References not assigned | Drag UI elements in inspector |
| Agent stuck at waypoint | Arrive distance too small | Increase to 1.5 or 2.0 |
| Pheromones not working | Parameters too extreme | Use default values first |

## Performance Metrics

Expected performance for 3 agents with 10 waypoints:
- Frame Rate: 60+ FPS
- Path Calculation: < 1ms per waypoint
- Collision Check: < 0.1ms per frame
- Pheromone Update: < 5ms per path
- Memory Usage: < 10MB additional

## File Dependencies

```
ACOTester.cs
├── requires: ACOManager.cs
├── requires: PathfindingTester.cs
└── requires: UniversalAgentCollisionHandler.cs

ACOManager.cs
├── requires: ACOAlgorithm.cs
└── requires: ACOGraph.cs

ACOAlgorithm.cs
├── requires: ACOGraph.cs
└── requires: PheromoneConnection.cs

ACOGraph.cs
└── requires: PheromoneConnection.cs

UniversalAgentCollisionHandler.cs
├── requires: ACOTester.cs
└── requires: PathfindingTester.cs

VisGraphWaypointManager.cs
└── requires: VisGraphConnection.cs
```

## Unity Requirements

- Unity 2020.3 or higher
- TextMeshPro package installed
- 3D project template
- C# .NET Standard 2.0 or higher

## Next Steps After Implementation

1. Fine-tune ACO parameters for your environment
2. Add visualization for pheromone trails (optional)
3. Implement path cost display
4. Add difficulty levels with different speeds
5. Create multiple scenarios (pickup vs drop)
6. Add sound effects for collisions
7. Implement agent trails/path history
8. Add camera following agent behavior
9. Create leaderboard for fastest completion
10. Add weather/environmental effects
